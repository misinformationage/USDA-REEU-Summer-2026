# CC1101 → Nutrient HAT Live Bridge

This package replaces `sample_reading.json` with the real 18-byte payload
transmitted by the supplied MSP430 `main.cpp`.

## Files

- `RX_Demo_Sensors.cpp`
  - Receives the CC1101 packet.
  - Decodes the 18-byte big-endian payload.
  - Emits one JSON sensor observation.
- `start_radio_model.sh`
  - Compiles the receiver.
  - Runs the receiver.
  - Filters the JSON.
  - Pipes it into the existing `predict_and_log.py --stdin`.
- `payload_map.txt`
  - Documents every transmitted byte.

## Put these files in the same folder as

- `predict_and_log.py`
- `nutrient_stress_hat.pkl`
- `.venv/`
- `cc1100_raspi.cpp`
- `cc1100_raspi.h`

Example project folder:

```text
raspberry_pi_hat_inference_only/
├── .venv/
├── nutrient_stress_hat.pkl
├── predict_and_log.py
├── cc1100_raspi.cpp
├── cc1100_raspi.h
├── RX_Demo_Sensors.cpp
└── start_radio_model.sh
```

## Enable SPI

```bash
sudo raspi-config
```

Choose Interface Options → SPI → Enable, then reboot if requested.

## Make the launcher executable

```bash
chmod +x start_radio_model.sh
```

## Start live model inference

```bash
./start_radio_model.sh
```

Defaults are aligned with the supplied transmitter:

- MSP430 sender address: 1
- broadcast destination: 0
- Raspberry Pi receiver address: 3
- channel: 10
- frequency: 434 MHz
- modulation: 1 (GFSK 1.2 kbps)

Override a setting for one run, for example:

```bash
CHANNEL=10 FREQUENCY=434 MODULATION=1 ./start_radio_model.sh
```

## Run the dashboard

Keep `start_radio_model.sh` running in one terminal.

In a second terminal:

```bash
cd ~/Desktop/"Nutrient Stress"/raspberry_pi_hat_inference_only
./start_dashboard.sh
```

The website will update from:

```text
prediction_logs/hat_predictions.csv
```

## Important input limitations

1. The transmitter sends the same DHT22 temperature twice. Therefore,
   `Soil_Temperature` is currently a duplicate of ambient temperature, not a
   true soil-temperature measurement.

2. The transmitter sends the TSL2591 full-spectrum raw channel count. It does
   not currently calculate calibrated lux. Verify that this scale matches the
   `Light_Intensity` values used to train the HAT.

3. The physical sensor units must match the training dataset. Connecting real
   values removes the dummy input, but mismatched units can still produce
   unreliable model predictions.

4. This is inference-only. The bridge never calls `learn_one()`.
