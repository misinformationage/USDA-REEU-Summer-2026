// RX_Demo_Sensors.cpp
//
// Raspberry Pi 4 CC1101 receiver for the 18-byte payload transmitted by
// the MSP430 main.cpp.
//
// Standard output:
//   Only machine-readable lines prefixed with SENSOR_JSON:
//
// Standard error:
//   Human-readable diagnostics.
//
// This lets start_radio_model.sh filter the JSON and send it to
// predict_and_log.py --stdin without using sample_reading.json.

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <locale>
#include <sstream>
#include <string>
#include <unistd.h>

#include <wiringPi.h>
#include "cc1100_raspi.h"

namespace {

constexpr std::size_t RX_BUFFER_SIZE = 64;
constexpr std::size_t SENSOR_PAYLOAD_SIZE = 18;

CC1100 cc1100;

volatile bool packet_ready = false;
volatile bool keep_running = true;

uint8_t rx_fifo[RX_BUFFER_SIZE] = {0};
uint8_t packet_length = 0;
uint8_t receiver_address = 0;
uint8_t sender_address = 0;
int8_t rssi_dbm = 0;
uint8_t lqi = 0;

volatile uint8_t my_address = 0x03;
uint8_t expected_sender = 0x01;
uint8_t channel = 10;
uint8_t ism_setting = 2;   // 2 = 433/434 MHz
uint8_t mode_setting = 1;  // 1 = GFSK 1.2 kbps

uint16_t read_be_u16(const uint8_t* bytes) {
    return static_cast<uint16_t>(
        (static_cast<uint16_t>(bytes[0]) << 8) |
        static_cast<uint16_t>(bytes[1])
    );
}

int16_t read_be_i16(const uint8_t* bytes) {
    return static_cast<int16_t>(read_be_u16(bytes));
}

uint8_t parse_frequency(const char* value) {
    const int frequency = std::atoi(value);

    switch (frequency) {
        case 315: return 1;
        case 433:
        case 434: return 2;
        case 868: return 3;
        case 915: return 4;
        default:
            throw std::runtime_error(
                "Unsupported frequency. Use 315, 433/434, 868, or 915."
            );
    }
}

uint8_t parse_modulation(const char* value) {
    const int modulation = std::atoi(value);

    switch (modulation) {
        case 1:   return 1;  // GFSK 1.2 kbps
        case 38:  return 2;  // GFSK 38.4 kbps
        case 100: return 3;  // GFSK 100 kbps
        case 250: return 4;  // MSK 250 kbps
        case 500: return 5;  // MSK 500 kbps
        case 4:   return 6;  // OOK 4.8 kbps
        default:
            throw std::runtime_error(
                "Unsupported modulation. Use 1, 38, 100, 250, 500, or 4."
            );
    }
}

void print_help(const char* program) {
    std::fprintf(
        stderr,
        "Usage: sudo %s [-a receiver_address] [-s sender_address]\\n"
        "               [-c channel] [-f frequency] [-m modulation]\\n\\n"
        "Defaults matching the supplied MSP430 main.cpp:\\n"
        "  receiver address: 3\\n"
        "  expected sender:  1\\n"
        "  channel:          10\\n"
        "  frequency:        434\\n"
        "  modulation:       1 (GFSK 1.2 kbps)\\n\\n"
        "Use -s 0 to accept packets from any sender.\\n",
        program
    );
}

void radio_interrupt() {
    // Do not overwrite a packet that the main loop has not processed yet.
    if (packet_ready) {
        return;
    }

    if (cc1100.packet_available()) {
        packet_length = 0;
        receiver_address = 0;
        sender_address = 0;
        rssi_dbm = 0;
        lqi = 0;

        // SpaceTeddy's library fills rx_fifo and updates the metadata refs.
        cc1100.get_payload(
            rx_fifo,
            packet_length,
            receiver_address,
            sender_address,
            rssi_dbm,
            lqi
        );

        packet_ready = true;
    }
}

const uint8_t* find_sensor_payload() {
    // SpaceTeddy packet format:
    // [0] packet length, [1] receiver, [2] sender, [3..] payload.
    //
    // Some library revisions expose the complete RF frame in rx_fifo, while
    // others may expose only the payload. Handle both layouts.
    if (packet_length == SENSOR_PAYLOAD_SIZE) {
        return &rx_fifo[0];
    }

    if (packet_length >= SENSOR_PAYLOAD_SIZE + 2) {
        return &rx_fifo[3];
    }

    if (rx_fifo[0] >= SENSOR_PAYLOAD_SIZE + 2) {
        return &rx_fifo[3];
    }

    return nullptr;
}

void emit_sensor_json(const uint8_t* payload) {
    // Payload layout from the supplied MSP430 main.cpp:
    //  0..1   soil moisture percentage
    //  2..3   DHT22 temperature, tenths of degree C
    //  4..5   duplicated temperature, tenths of degree C
    //  6..7   DHT22 humidity, tenths of percent
    //  8..9   TSL2591 full-spectrum raw count
    // 10..11  pH x 100
    // 12..13  nitrogen
    // 14..15  phosphorus
    // 16..17  potassium

    const uint16_t soil_moisture_raw = read_be_u16(payload + 0);
    const int16_t dht_temperature_tenths = read_be_i16(payload + 2);
    const int16_t duplicate_temperature_tenths = read_be_i16(payload + 4);
    const uint16_t humidity_tenths = read_be_u16(payload + 6);
    const uint16_t light_raw = read_be_u16(payload + 8);
    const uint16_t ph_hundredths = read_be_u16(payload + 10);
    const uint16_t nitrogen = read_be_u16(payload + 12);
    const uint16_t phosphorus = read_be_u16(payload + 14);
    const uint16_t potassium = read_be_u16(payload + 16);

    const double soil_moisture = static_cast<double>(soil_moisture_raw);
    const double ambient_temperature =
        static_cast<double>(dht_temperature_tenths) / 10.0;
    const double soil_temperature =
        static_cast<double>(duplicate_temperature_tenths) / 10.0;
    const double humidity = static_cast<double>(humidity_tenths) / 10.0;
    const double light_intensity = static_cast<double>(light_raw);
    const double soil_ph = static_cast<double>(ph_hundredths) / 100.0;

    std::ostringstream json;
    json.imbue(std::locale::classic());
    json << std::fixed << std::setprecision(2);

    json
        << "{"
        << "\"Soil_Moisture\":" << soil_moisture << ","
        << "\"Ambient_Temperature\":" << ambient_temperature << ","
        << "\"Soil_Temperature\":" << soil_temperature << ","
        << "\"Humidity\":" << humidity << ","
        << "\"Light_Intensity\":" << light_intensity << ","
        << "\"Soil_pH\":" << soil_ph << ","
        << "\"Nitrogen_Level\":" << nitrogen << ","
        << "\"Phosphorus_Level\":" << phosphorus << ","
        << "\"Potassium_Level\":" << potassium
        << "}";

    // The shell bridge extracts only lines with this exact prefix.
    std::cout << "SENSOR_JSON:" << json.str() << std::endl;

    std::fprintf(
        stderr,
        "[RF] sender=%u receiver=%u length=%u RSSI=%d dBm LQI=%u\\n",
        static_cast<unsigned>(sender_address),
        static_cast<unsigned>(receiver_address),
        static_cast<unsigned>(packet_length),
        static_cast<int>(rssi_dbm),
        static_cast<unsigned>(lqi)
    );

    std::fprintf(
        stderr,
        "[SENSORS] moisture=%.2f ambient=%.2f soil_temp=%.2f "
        "humidity=%.2f light_raw=%.2f pH=%.2f N=%u P=%u K=%u\\n",
        soil_moisture,
        ambient_temperature,
        soil_temperature,
        humidity,
        light_intensity,
        soil_ph,
        static_cast<unsigned>(nitrogen),
        static_cast<unsigned>(phosphorus),
        static_cast<unsigned>(potassium)
    );
}

}  // namespace

int main(int argc, char** argv) {
    int option = 0;

    try {
        while ((option = getopt(argc, argv, "ha:s:c:f:m:")) != -1) {
            switch (option) {
                case 'h':
                    print_help(argv[0]);
                    return EXIT_SUCCESS;

                case 'a': {
                    const int parsed = std::atoi(optarg);
                    if (parsed < 1 || parsed > 255) {
                        throw std::runtime_error(
                            "Receiver address must be between 1 and 255."
                        );
                    }
                    my_address = static_cast<uint8_t>(parsed);
                    break;
                }

                case 's': {
                    const int parsed = std::atoi(optarg);
                    if (parsed < 0 || parsed > 255) {
                        throw std::runtime_error(
                            "Sender address must be between 0 and 255."
                        );
                    }
                    expected_sender = static_cast<uint8_t>(parsed);
                    break;
                }

                case 'c': {
                    const int parsed = std::atoi(optarg);
                    if (parsed < 1 || parsed > 255) {
                        throw std::runtime_error(
                            "Channel must be between 1 and 255."
                        );
                    }
                    channel = static_cast<uint8_t>(parsed);
                    break;
                }

                case 'f':
                    ism_setting = parse_frequency(optarg);
                    break;

                case 'm':
                    mode_setting = parse_modulation(optarg);
                    break;

                default:
                    print_help(argv[0]);
                    return EXIT_FAILURE;
            }
        }
    } catch (const std::exception& error) {
        std::fprintf(stderr, "Argument error: %s\\n", error.what());
        print_help(argv[0]);
        return EXIT_FAILURE;
    }

    if (wiringPiSetup() == -1) {
        std::fprintf(stderr, "wiringPiSetup() failed.\\n");
        return EXIT_FAILURE;
    }

    std::fprintf(stderr, "[BOOT] Initializing CC1101 receiver...\\n");

    cc1100.begin(my_address);
    cc1100.set_mode(mode_setting);
    cc1100.set_ISM(ism_setting);
    cc1100.set_channel(channel);
    cc1100.set_output_power_level(0);
    cc1100.set_myaddr(my_address);

    // Assert GDO2 when a packet has been received with CRC OK.
    cc1100.spi_write_register(IOCFG2, 0x06);

    pinMode(GDO2, INPUT);
    pullUpDnControl(GDO2, PUD_DOWN);

    if (wiringPiISR(GDO2, INT_EDGE_RISING, &radio_interrupt) < 0) {
        std::fprintf(stderr, "Could not attach GDO2 interrupt.\\n");
        return EXIT_FAILURE;
    }

    cc1100.receive();

    std::fprintf(
        stderr,
        "[READY] address=%u sender_filter=%u channel=%u "
        "ISM_setting=%u mode_setting=%u\\n",
        static_cast<unsigned>(my_address),
        static_cast<unsigned>(expected_sender),
        static_cast<unsigned>(channel),
        static_cast<unsigned>(ism_setting),
        static_cast<unsigned>(mode_setting)
    );

    while (keep_running) {
        if (!packet_ready) {
            delay(2);
            continue;
        }

        if (expected_sender != 0 && sender_address != expected_sender) {
            std::fprintf(
                stderr,
                "[IGNORED] Packet from sender %u; expected %u.\\n",
                static_cast<unsigned>(sender_address),
                static_cast<unsigned>(expected_sender)
            );
        } else {
            const uint8_t* payload = find_sensor_payload();

            if (payload == nullptr) {
                std::fprintf(
                    stderr,
                    "[ERROR] Unexpected packet length/layout. "
                    "packet_length=%u first_byte=%u; expected 18-byte payload.\\n",
                    static_cast<unsigned>(packet_length),
                    static_cast<unsigned>(rx_fifo[0])
                );
            } else {
                emit_sensor_json(payload);
            }
        }

        packet_ready = false;
        cc1100.receive();
    }

    return EXIT_SUCCESS;
}
