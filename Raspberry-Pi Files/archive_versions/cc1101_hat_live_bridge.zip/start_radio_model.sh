#!/usr/bin/env bash
set -Eeuo pipefail

# Receives live CC1101 packets, filters the SENSOR_JSON line, and sends each
# real sensor observation into the already-trained HAT inference program.
#
# It does NOT call learn_one(). predict_and_log.py remains inference-only.

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

RX_SOURCE="${RX_SOURCE:-RX_Demo_Sensors.cpp}"
RX_BINARY="${RX_BINARY:-RX_Demo_Sensors}"

RX_ADDRESS="${RX_ADDRESS:-3}"
EXPECTED_SENDER="${EXPECTED_SENDER:-1}"
CHANNEL="${CHANNEL:-10}"
FREQUENCY="${FREQUENCY:-434}"
MODULATION="${MODULATION:-1}"

PYTHON="$SCRIPT_DIR/.venv/bin/python"
PREDICTOR="$SCRIPT_DIR/predict_and_log.py"

if [[ ! -x "$PYTHON" ]]; then
    echo "ERROR: Python virtual environment not found at $PYTHON" >&2
    echo "Create/activate .venv first." >&2
    exit 1
fi

if [[ ! -f "$PREDICTOR" ]]; then
    echo "ERROR: predict_and_log.py not found in $SCRIPT_DIR" >&2
    exit 1
fi

if [[ ! -f "$SCRIPT_DIR/nutrient_stress_hat.pkl" ]]; then
    echo "ERROR: nutrient_stress_hat.pkl not found in $SCRIPT_DIR" >&2
    exit 1
fi

if [[ ! -f "$SCRIPT_DIR/cc1100_raspi.cpp" ]] ||
   [[ ! -f "$SCRIPT_DIR/cc1100_raspi.h" ]]; then
    echo "ERROR: Copy cc1100_raspi.cpp and cc1100_raspi.h into $SCRIPT_DIR" >&2
    exit 1
fi

if [[ ! -x "$SCRIPT_DIR/$RX_BINARY" ]] ||
   [[ "$SCRIPT_DIR/$RX_SOURCE" -nt "$SCRIPT_DIR/$RX_BINARY" ]]; then
    echo "Compiling $RX_BINARY..." >&2
    g++ \
        -std=c++17 \
        -O2 \
        -Wall \
        -Wextra \
        "$SCRIPT_DIR/$RX_SOURCE" \
        "$SCRIPT_DIR/cc1100_raspi.cpp" \
        -o "$SCRIPT_DIR/$RX_BINARY" \
        -lwiringPi
fi

echo "====================================================" >&2
echo " CC1101 → Nutrient HAT live inference" >&2
echo "====================================================" >&2
echo "Receiver address : $RX_ADDRESS" >&2
echo "Expected sender  : $EXPECTED_SENDER" >&2
echo "Channel          : $CHANNEL" >&2
echo "Frequency        : $FREQUENCY MHz" >&2
echo "Modulation       : $MODULATION" >&2
echo "CSV log          : prediction_logs/hat_predictions.csv" >&2
echo "HAT update       : DISABLED (inference only)" >&2
echo "Press Ctrl+C to stop." >&2
echo >&2

# Library/debug output can contain non-JSON text. The C++ receiver prefixes
# real observations with SENSOR_JSON:, and sed removes everything else.
sudo stdbuf -oL -eL "$SCRIPT_DIR/$RX_BINARY" \
    -a "$RX_ADDRESS" \
    -s "$EXPECTED_SENDER" \
    -c "$CHANNEL" \
    -f "$FREQUENCY" \
    -m "$MODULATION" \
    2> >(tee -a "$SCRIPT_DIR/radio_receiver.log" >&2) \
| stdbuf -oL sed -n 's/^SENSOR_JSON://p' \
| "$PYTHON" "$PREDICTOR" --stdin
