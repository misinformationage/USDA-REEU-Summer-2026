# Preserve-All CC1101 → HAT Bridge

This revision preserves the transmitter's test arrangement exactly.

It does not:
- remove duplicate temperature values
- average the two temperature fields
- convert the raw light count to another value
- clamp sensor readings
- replace readings with defaults
- delete any of the 18 payload bytes

Saved logs:

- `prediction_logs/raw_cc1101_packets.jsonl`
  - all 18 payload bytes
  - every raw integer
  - sender, receiver, packet length, RSSI, and LQI

- `prediction_logs/model_sensor_inputs.jsonl`
  - the exact nine values sent into the HAT

- `prediction_logs/hat_predictions.csv`
  - predictions and probabilities

Replace the earlier versions of:

- `RX_Demo_Sensors.cpp`
- `start_radio_model.sh`

Then run:

```bash
chmod +x start_radio_model.sh
./start_radio_model.sh
```

The HAT remains inference-only.
